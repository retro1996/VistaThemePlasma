#!/bin/bash
cd $1
ln -s battery-010.png battery-caution.png
ln -s battery-010-charging.png battery-caution-charging.png
ln -s battery-000-charging.png battery-empty-charging.png
ln -s battery-000.png battery-empty.png
ln -s battery-100.png battery-full.png
ln -s battery-100-charging.png battery-full-charging.png
ln -s battery-100-charging.png battery-full-charged.png
ln -s battery-060-charging.png battery-good-charging.png
ln -s battery-060.png battery-good.png
ln -s battery-020.png battery-low.png
ln -s battery-020-charging.png battery-low-charging.png
 
