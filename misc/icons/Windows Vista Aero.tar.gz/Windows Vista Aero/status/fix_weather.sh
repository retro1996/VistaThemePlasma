#!/bin/bash
mv stock_weather-few-clouds.png weather-clouds.png
ln -s weather-clouds.png weather-clouds-symbolic.png
